package com.lithoykai.radio_peao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RadioPeaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RadioPeaoApplication.class, args);
	}

}
